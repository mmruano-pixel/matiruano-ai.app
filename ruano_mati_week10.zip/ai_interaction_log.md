# AI Interaction Log

### Task: Starter Setup
**Prompt:** "Set up the starter project files for this Streamlit assignment. Create or fill these files with minimal valid starter content: app.py, requirements.txt, memory.json, ai_interaction_log.md, .streamlit/config.toml. Also assume there is a chats/ folder and a .streamlit/secrets.toml file that I will fill manually."
**AI Suggestion:** The AI suggested creating the required starter files with simple valid content, including a minimal Streamlit app, the correct requirements, an empty `memory.json`, a starter log template, and the dark theme config.
**My Modifications & Reflections:** This mostly worked for getting the project started. One thing I had to double-check later was the `chats/` folder because the files were there but the folder had not actually been created yet. Other than that, it gave me a clean starting point and matched the assignment structure pretty well.

### Task: Task 1 Part A
**Prompt:** "Now complete only Task 1 Part A in app.py. Load Hugging Face token from st.secrets['HF_TOKEN'], send a single hardcoded test message, use the Hugging Face router and model, display the model response, and handle errors gracefully."
**AI Suggestion:** The AI suggested building a very small test app that sets the page config, loads the token from Streamlit secrets, sends one hardcoded message to the Hugging Face API, shows the reply, and displays clear error messages for token, network, and response issues.
**My Modifications & Reflections:** The project ended up moving past this stage pretty quickly, so the exact Part A version did not stay in the final code. Still, the important parts carried forward, especially the API connection, error handling, and token loading logic. Later on I had to fix the token access so it used `st.secrets["HF_TOKEN"]` exactly to better match the rubric.

### Task: Task 1 Part B
**Prompt:** "Now extend the working Part A code to complete only Task 1 Part B. Replace the hardcoded test message with real chat input using st.chat_message and st.chat_input, store conversation history in st.session_state, and render the full conversation history."
**AI Suggestion:** The AI suggested switching from one test message to a real multi-turn chat using native Streamlit chat components and keeping the full conversation history in session state so the model would keep context.
**My Modifications & Reflections:** This part worked well and was one of the more straightforward steps. I liked that it used the built-in Streamlit chat UI instead of trying to style everything manually. It felt simple enough for the assignment and easy to understand when I looked back through the code.

### Task: Task 1 Part C
**Prompt:** "Now extend the app to complete only Task 1 Part C: Chat Management. Add a New Chat button in the sidebar, show all current chats with title and timestamp, highlight the active chat, allow switching, and add delete buttons."
**AI Suggestion:** The AI suggested creating a session-state structure for multiple chats where each chat has an id, title, timestamp, and messages. It also suggested using the sidebar with buttons for switching chats and deleting them.
**My Modifications & Reflections:** This worked, but I needed to think a little more carefully about the logic for active chats and what should happen after deleting one. The final version handles that by switching to another chat or showing an empty state if none are left. I think this part meets the rubric while still staying beginner-friendly.

### Task: Task 1 Part D
**Prompt:** "Now extend the app to complete only Task 1 Part D: Chat Persistence. Save each chat as a separate JSON file in chats/, load them on startup, and delete the file when the chat is deleted."
**AI Suggestion:** The AI suggested using helper functions to create the `chats/` folder, save one chat per JSON file using the chat id as the filename, load all chats at startup, and remove the matching file when a chat is deleted.
**My Modifications & Reflections:** This part definitely improved the app because it made the chats survive refreshes and app restarts. I thought the helper functions made the code easier to follow. I also liked that the filenames stayed simple instead of trying to make them based on the chat title, which could get messy.

### Task: Task 2 Streaming
**Prompt:** "Now extend the app to complete only Task 2: Response Streaming. Use stream=True, handle server-sent event streaming, display the assistant reply incrementally, add a very short delay between chunks, and save the final streamed response."
**AI Suggestion:** The AI suggested adding a separate helper for streamed API responses, parsing SSE lines safely, rendering the response incrementally with a placeholder, and falling back to the normal non-streaming request if streaming failed.
**My Modifications & Reflections:** This was probably the trickiest part because streaming can be easy to break if the response format is weird. The final version worked better after keeping a fallback path in case streaming fails. I think adding the tiny delay was a good idea because otherwise the model can respond so fast that it barely looks like streaming.

### Task: Task 3 Memory
**Prompt:** "Now extend the app to complete only Task 3: User Memory. After each assistant response, make a second API call to extract personal traits or preferences, store them in memory.json, show them in the sidebar, allow clearing memory, and inject saved memory into future prompts."
**AI Suggestion:** The AI suggested adding helper functions to load and save `memory.json`, storing memory in session state, using a second lightweight extraction prompt that returns JSON, merging new memory carefully, and injecting the saved memory into future conversations through a system prompt.
**My Modifications & Reflections:** This part worked, but I wanted to keep it simple so it did not become too complicated for the assignment. I like that the memory categories are limited and the file is just plain JSON. I also thought it was important to handle invalid or empty memory files gracefully, because that feels like something a grader might test.
